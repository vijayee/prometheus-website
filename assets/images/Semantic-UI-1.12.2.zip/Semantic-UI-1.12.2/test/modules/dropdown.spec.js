describe("UI Dropdown", function() {

  moduleTests({
    module  : 'dropdown',
    element : '.ui.dropdown'
  });

});